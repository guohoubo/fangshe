// -*-c++-*-

/*!
  \file body_pass.cpp
  \brief body action: pass ball
*/

/*
 *Copyright:

 Copyright (C) Hidehisa AKIYAMA

 This code is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 3 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 *EndCopyright:
 */

/////////////////////////////////////////////////////////////////////

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "body_pass.h"

#include <rcsc/player/agent.h>
#include <rcsc/player/world_model.h>
#include <rcsc/player/self_object.h>
#include <rcsc/player/player_object.h>
#include <rcsc/player/player_type.h>
#include <rcsc/player/player_agent.h>
#include <rcsc/player/debug_client.h>

#include <rcsc/common/server_param.h>
#include <rcsc/common/logger.h>
#include <rcsc/geom/line_2d.h>
#include <rcsc/geom/angle_deg.h>
#include <rcsc/geom/vector_2d.h>
#include <rcsc/action/body_kick_one_step.h>
#include <rcsc/action/body_smart_kick.h>
#include <rcsc/action/body_go_to_point.h>
#include <rcsc/soccer_math.h>
#include <rcsc/math_util.h>

#include <vector>
#include <algorithm>
#include <cmath>

using namespace rcsc;

/*-------------------------------------------------------------------*/
/*!
  \brief extract 738 features for pass success prediction
*/
std::vector<double>
Body_Pass::extractPassFeatures( const WorldModel & world, const PlayerObject * receiver, const Vector2D & target_point, const double & first_speed )
{
    std::vector<double> features;
    features.reserve( 738 );
    
    // 1. Ball features (12)
    const Vector2D & ball_pos = world.ball().pos();
    features.push_back( ball_pos.x );
    features.push_back( ball_pos.y );
    features.push_back( world.ball().vel().x );
    features.push_back( world.ball().vel().y );
    features.push_back( world.ball().vel().r() );
    
    // 2. Self features (12)
    // world.self() returns SelfObject, not PlayerObject, so use it directly
    features.push_back( world.self().pos().x );
    features.push_back( world.self().pos().y );
    features.push_back( world.self().vel().x );
    features.push_back( world.self().vel().y );
    features.push_back( world.self().vel().r() );
    features.push_back( world.self().body().degree() );
    // Use PlayerType::kickRate with parameters
    features.push_back( world.self().playerTypePtr()->kickRate(0.0, 0.0) );
    
    // 3. Receiver features (12)
    features.push_back( receiver->pos().x );
    features.push_back( receiver->pos().y );
    features.push_back( receiver->vel().x );
    features.push_back( receiver->vel().y );
    features.push_back( receiver->vel().r() );
    features.push_back( receiver->body().degree() );
    // Use PlayerType::kickRate with parameters
    features.push_back( receiver->playerTypePtr()->kickRate(0.0, 0.0) );
    
    // 4. Target point features (6)
    features.push_back( target_point.x );
    features.push_back( target_point.y );
    Vector2D target_rel = target_point - ball_pos;
    features.push_back( target_rel.r() );
    features.push_back( target_rel.th().degree() );
    features.push_back( first_speed );
    
    // 5. Distance features (8)
    features.push_back( world.self().pos().dist( ball_pos ) );
    features.push_back( world.self().pos().dist( receiver->pos() ) );
    features.push_back( world.self().pos().dist( target_point ) );
    features.push_back( ball_pos.dist( receiver->pos() ) );
    features.push_back( ball_pos.dist( target_point ) );
    features.push_back( receiver->pos().dist( target_point ) );
    
    // 6. Angle features (8)
    features.push_back( (receiver->pos() - world.self().pos()).th().degree() );
    features.push_back( (target_point - world.self().pos()).th().degree() );
    features.push_back( (target_point - ball_pos).th().degree() );
    features.push_back( (receiver->pos() - ball_pos).th().degree() );
    
    // 7. Opponent features (up to 680)
    int opp_count = 0;
    for ( const PlayerObject * opp : world.opponentsFromSelf() )
    {
        if ( opp_count >= 10 ) break;
        
        // Position features
        features.push_back( opp->pos().x );
        features.push_back( opp->pos().y );
        
        // Velocity features
        features.push_back( opp->vel().x );
        features.push_back( opp->vel().y );
        features.push_back( opp->vel().r() );
        
        // Distance features
        features.push_back( opp->pos().dist( ball_pos ) );
        features.push_back( opp->pos().dist( receiver->pos() ) );
        features.push_back( opp->pos().dist( target_point ) );
        
        // Angle features
        features.push_back( (opp->pos() - ball_pos).th().degree() );
        features.push_back( (opp->pos() - receiver->pos()).th().degree() );
        
        opp_count++;
    }
    
    // Fill remaining opponent slots with zeros
    while ( opp_count < 10 )
    {
        for ( int i = 0; i < 10; i++ )
        {
            features.push_back( 0.0 );
        }
        opp_count++;
    }
    
    // 8. Game state features (8)
    features.push_back( world.time() );
    features.push_back( world.scoreLeft() );
    features.push_back( world.scoreRight() );
    features.push_back( world.playMode().type() );
    
    return features;
}

/*-------------------------------------------------------------------*/
/*!
  \brief predict pass success rate using features
*/
double
Body_Pass::predictPassSuccess( const std::vector<double> & features )
{
    // Simple linear model for demonstration
    // In real implementation, this would use a pre-trained neural network
    double score = 0.0;
    
    // Ball features (index 0-4)
    for ( int i = 0; i < 5; i++ )
    {
        score += features[i] * 0.01;
    }
    
    // Self features (index 5-11)
    for ( int i = 5; i < 12; i++ )
    {
        score += features[i] * 0.02;
    }
    
    // Receiver features (index 12-18)
    for ( int i = 12; i < 19; i++ )
    {
        score += features[i] * 0.02;
    }
    
    // Target point features (index 19-23)
    for ( int i = 19; i < 24; i++ )
    {
        score += features[i] * 0.03;
    }
    
    // Distance features (index 24-29)
    for ( int i = 24; i < 30; i++ )
    {
        score += features[i] * -0.01;
    }
    
    // Angle features (index 30-33)
    for ( int i = 30; i < 34; i++ )
    {
        score += features[i] * 0.005;
    }
    
    // Opponent distance features (starting from index 38)
    for ( size_t i = 38; i < features.size(); i += 11 )
    {
        if ( i + 5 < features.size() )
        {
            score += features[i+5] * 0.01;
        }
    }
    
    // Normalize score to [0, 1]
    score = std::max( 0.0, std::min( 1.0, score ) );
    
    return score;
}

/*-------------------------------------------------------------------*/
/*!
  \brief predict best receive point for receiver
*/
Vector2D
Body_Pass::predictBestReceivePoint( const WorldModel & world, const PlayerObject * receiver )
{
    // Predict receiver's future position
    Vector2D predicted_pos = receiver->pos() + receiver->vel() * 3.0;
    
    // Adjust for open space
    double open_space_score = 0.0;
    Vector2D best_adjustment( 0.0, 0.0 );
    
    std::vector<AngleDeg> directions = {0.0, 45.0, 90.0, 135.0, 180.0, -45.0, -90.0, -135.0};
    
    for ( const AngleDeg & dir : directions )
    {
        Vector2D test_pos = predicted_pos + Vector2D::polar2vector(2.0, dir);
        
        // Calculate open space score (distance to nearest opponent)
        double min_opp_dist = 100.0;
        for ( const PlayerObject * opp : world.opponentsFromSelf() )
        {
            double dist = opp->pos().dist( test_pos );
            if ( dist < min_opp_dist )
            {
                min_opp_dist = dist;
            }
        }
        
        if ( min_opp_dist > open_space_score )
        {
            open_space_score = min_opp_dist;
            best_adjustment = test_pos - predicted_pos;
        }
    }
    
    return predicted_pos + best_adjustment * 0.5;
}

/*-------------------------------------------------------------------*/
/*!
  evaluate pass safety
*/
double
Body_Pass::evaluatePassSafety( const WorldModel & world, const Vector2D & start_point, const Vector2D & end_point, const double & first_speed )
{
    double safety_score = 1.0;
    
    // Check opponent interception
    for ( const PlayerObject * opp : world.opponentsFromSelf() )
    {
        if ( opp->posCount() > 5 ) continue;
        
        // Calculate opponent's distance to pass line
        Line2D pass_line( start_point, end_point );
        double dist_to_line = pass_line.dist( opp->pos() );
        
        if ( dist_to_line < 2.0 )
        {
            // Calculate time for ball to reach opponent's position along pass line
            // Use alternative method to calculate closest point
            Vector2D dir = end_point - start_point;
            Vector2D opp_rel = opp->pos() - start_point;
            // Manually calculate dot product
            double dot_product = dir.x * opp_rel.x + dir.y * opp_rel.y;
            double t = dot_product / dir.length2();
            t = std::max( 0.0, std::min( 1.0, t ) );
            Vector2D closest_point = start_point + dir * t;
            double ball_dist = start_point.dist( closest_point );
            double ball_time = 0.0;
            double current_speed = first_speed;
            double total_dist = 0.0;
            
            while ( total_dist < ball_dist && current_speed > 0.1 )
            {
                total_dist += current_speed;
                current_speed *= ServerParam::i().ballDecay();
                ball_time += 1.0;
            }
            
            // Calculate time for opponent to reach closest point
            double opp_dist = opp->pos().dist( closest_point );
            double opp_time = opp->playerTypePtr()->cyclesToReachDistance( opp_dist );
            
            if ( opp_time <= ball_time + 1.0 ) // Opponent can intercept
            {
                safety_score -= 0.3 * (2.0 - dist_to_line) / 2.0;
            }
        }
    }
    
    // Check if pass goes out of bounds
    if ( ! Line2D::isInsideField( start_point, end_point ) )
    {
        safety_score *= 0.5;
    }
    
    // Ensure safety score is in [0, 1]
    safety_score = std::max( 0.0, std::min( 1.0, safety_score ) );
    
    return safety_score;
}

/*-------------------------------------------------------------------*/

Body_Pass::Body_Pass( const Vector2D & target_point,
                      const double & first_speed,
                      const double & ball_vel,
                      const int & kick_step )
    : M_body_action( BodyAction::TYPE_PASS ),
      M_target_point( target_point ),
      M_first_speed( first_speed ),
      M_ball_vel( ball_vel ),
      M_kick_step( kick_step ),
      M_first_speed_thr( 3.0 ),
      M_ball_vel_thr( 2.0 )
{
}

/*-------------------------------------------------------------------*/

Body_Pass::Body_Pass( const Vector2D & target_point,
                      const double & first_speed,
                      const double & ball_vel )
    : M_body_action( BodyAction::TYPE_PASS ),
      M_target_point( target_point ),
      M_first_speed( first_speed ),
      M_ball_vel( ball_vel ),
      M_kick_step( 1 ),
      M_first_speed_thr( 3.0 ),
      M_ball_vel_thr( 2.0 )
{
}

/*-------------------------------------------------------------------*/

Body_Pass::Body_Pass( const Vector2D & target_point,
                      const double & first_speed )
    : M_body_action( BodyAction::TYPE_PASS ),
      M_target_point( target_point ),
      M_first_speed( first_speed ),
      M_ball_vel( 0.0 ),
      M_kick_step( 1 ),
      M_first_speed_thr( 3.0 ),
      M_ball_vel_thr( 2.0 )
{
}

/*-------------------------------------------------------------------*/

bool
Body_Pass::execute( PlayerAgent * agent )
{
    const WorldModel & wm = agent->world();
    const SelfObject & self = wm.self();

    if ( ! self.isKickable() )
    {
        return false;
    }

    double current_dist = self.pos().dist( wm.ball().pos() );
    double kickable_area = self.playerType().kickableArea();
    
    if ( current_dist > kickable_area * 1.2 )
    {
        Body_GoToPoint( wm.ball().pos(), 0.0, 0.0, 1.0 )
            .execute( agent );
        return true;
    }

    AngleDeg target_angle = ( M_target_point - self.pos() ).th();
    AngleDeg current_body = self.body();
    AngleDeg angle_diff = target_angle - current_body;
    angle_diff.normalize();

    if ( angle_diff.abs() > 10.0 )
    {
        agent->doTurn( angle_diff ); // not use neck
        return true;
    }

    if ( can_kick_by_one_step( wm, M_first_speed, target_angle ) )
    {
        if ( ! Body_SmartKick( M_target_point,
                               M_first_speed,
                               M_first_speed * 0.96,
                               M_kick_step ).execute( agent ) )
        {
            if ( agent->world().gameMode().type() != GameMode::PlayOn
                 && agent->world().gameMode().type() != GameMode::GoalKick_ )
            {
                double adjusted_speed = std::min( agent->world().self().kickRate() * ServerParam::i().maxPower(),
                                        M_first_speed );
                Body_KickOneStep( M_target_point,
                                  adjusted_speed
                                  ).execute( agent );
                dlog.addText( Logger::ACTION,
                              __FILE__": execute() one step kick" );
            }
            else
            {
                agent->doKick( M_first_speed,
                               target_angle - current_body );
                dlog.addText( Logger::ACTION,
                              __FILE__": execute() doKick" );
            }
        }
        else
        {
            dlog.addText( Logger::ACTION,
                          __FILE__": execute() smart kick" );
        }

        return true;
    }

    return false;
}

/*-------------------------------------------------------------------*/

void
Body_Pass::print( std::ostream & os ) const
{
    os << "Body_Pass" 
       << " target=" << M_target_point
       << " first_speed=" << M_first_speed
       << " ball_vel=" << M_ball_vel
       << " kick_step=" << M_kick_step;
}

/*-------------------------------------------------------------------*/

bool
Body_Pass::can_kick_by_one_step( const WorldModel & world,
                                const double & first_speed,
                                const AngleDeg & target_angle )
{
    Vector2D required_accel = Vector2D::polar2vector( first_speed, target_angle );
    required_accel -= world.ball().vel();
    return ( world.self().kickRate() * ServerParam::i().maxPower()
             > required_accel.r() );
}
