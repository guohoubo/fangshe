// -*-c++-*-

/*!
  \file omam_marking.cpp
  \brief OMAM (Optimal Matching Assignment Marking) system implementation
*/

/*
 *Copyright:

 Copyright (C) Hidehisa AKIYAMA

 This code is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 3 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 *EndCopyright:
 */

/////////////////////////////////////////////////////////////////////

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include "omam_marking.h"

#include <rcsc/player/world_model.h>
#include <rcsc/player/player_object.h>
#include <rcsc/common/server_param.h>
#include <rcsc/geom/line_2d.h>
#include <rcsc/soccer_math.h>

#include <vector>
#include <algorithm>
#include <cmath>

using namespace rcsc;

const int OMAM_Marking::MAX_OPPONENTS = 11;
const int OMAM_Marking::MAX_DEFENDERS = 11;

/*-------------------------------------------------------------------*/
/*!
  \brief calculate opponent threats
*/
std::vector< OMAM_Marking::OpponentThreat >
OMAM_Marking::calculateOpponentThreats( const WorldModel & world )
{
    std::vector< OpponentThreat > threats;
    
    for ( const PlayerObject * opp : world.opponentsFromSelf() )
    {
        if ( opp->posCount() > 5 ) continue;
        
        double threat_score = calculateThreatScore( world, opp );
        threats.emplace_back( opp, threat_score );
    }
    
    // Sort threats by threat score in descending order
    std::sort( threats.begin(), threats.end(),
               []( const OpponentThreat & a, const OpponentThreat & b ) {
                   return a.threat_score_ > b.threat_score_;
               } );
    
    return threats;
}

/*-------------------------------------------------------------------*/
/*!
  \brief calculate threat score for an opponent
*/
double
OMAM_Marking::calculateThreatScore( const WorldModel & world, const PlayerObject * opp )
{
    double score = 0.0;
    
    // 1. Distance to our goal
    double dist_to_goal = opp->pos().dist( Vector2D( -ServerParam::i().pitchHalfLength(), 0.0 ) );
    score += ( 100.0 - dist_to_goal ) * 0.3;
    
    // 2. Distance to ball
    double dist_to_ball = opp->distFromBall();
    if ( dist_to_ball < 10.0 )
    {
        score += ( 10.0 - dist_to_ball ) * 0.4;
    }
    
    // 3. Opponent speed
    score += opp->vel().r() * 0.1;
    
    // 4. Position in front of our goal
    if ( opp->pos().x < 0.0 )
    {
        score += 10.0;
    }
    
    // 5. Distance from opponent to ball compared to distance from nearest teammate to ball
    double min_teammate_dist = 100.0;
    for ( const PlayerObject * teammate : world.teammatesFromSelf() )
    {
        double dist = teammate->distFromBall();
        if ( dist < min_teammate_dist )
        {
            min_teammate_dist = dist;
        }
    }
    
    if ( dist_to_ball < min_teammate_dist )
    {
        score += 20.0;
    }
    
    return score;
}

/*-------------------------------------------------------------------*/
/*!
  \brief assign marking tasks to defenders
*/
std::vector< OMAM_Marking::MarkingAssignment >
OMAM_Marking::assignMarkingTasks( const WorldModel & world, const std::vector< OpponentThreat > & threats, int k_top )
{
    std::vector< MarkingAssignment > assignments;
    
    // Get all defenders (excluding goalkeeper)
    std::vector< const PlayerObject * > defenders;
    for ( const PlayerObject * teammate : world.teammatesFromSelf() )
    {
        if ( !teammate->goalie() )
        {
            defenders.push_back( teammate );
        }
    }
    
    // Add self if not already in the list
    if ( !world.self().goalie() )
    {
        bool self_in_list = false;
        for ( const PlayerObject * defender : defenders )
        {
            if ( defender->unum() == world.self().unum() )
            {
                self_in_list = true;
                break;
            }
        }
        if ( !self_in_list )
        {
            defenders.push_back( &world.self() );
        }
    }
    
    // Limit to k_top opponents
    int num_opponents = std::min( k_top, static_cast< int >( threats.size() ) );
    int num_defenders = std::min( static_cast< int >( defenders.size() ), num_opponents );
    
    if ( num_defenders == 0 || num_opponents == 0 )
    {
        return assignments;
    }
    
    // Build cost matrix
    std::vector< std::vector< double > > cost_matrix = buildCostMatrix( world, defenders, threats );
    
    // Solve assignment problem
    std::vector< int > assignment = solveAssignmentProblem( cost_matrix );
    
    // Create assignments
    for ( int i = 0; i < num_defenders; ++i )
    {
        int opp_idx = assignment[i];
        if ( opp_idx < num_opponents )
        {
            const PlayerObject * defender = defenders[i];
            const PlayerObject * opponent = threats[opp_idx].opp_;
            double cost = cost_matrix[i][opp_idx];
            Vector2D marking_pos = calculateMarkingPosition( world, defender, opponent );
            
            assignments.emplace_back( defender, opponent, cost, marking_pos );
        }
    }
    
    return assignments;
}

/*-------------------------------------------------------------------*/
/*!
  \brief build cost matrix for assignment problem
*/
std::vector< std::vector< double > >
OMAM_Marking::buildCostMatrix( const WorldModel & world, const std::vector< const PlayerObject * > & defenders, const std::vector< OpponentThreat > & threats )
{
    int num_defenders = defenders.size();
    int num_opponents = threats.size();
    
    std::vector< std::vector< double > > cost_matrix( num_defenders, std::vector< double >( num_opponents, 0.0 ) );
    
    for ( int i = 0; i < num_defenders; ++i )
    {
        const PlayerObject * defender = defenders[i];
        
        for ( int j = 0; j < num_opponents; ++j )
        {
            const PlayerObject * opponent = threats[j].opp_;
            
            // Cost is based on distance and threat level
            double distance = defender->pos().dist( opponent->pos() );
            double threat = threats[j].threat_score_;
            
            // Lower cost for closer defenders and higher threat opponents
            cost_matrix[i][j] = distance / ( threat + 1.0 );
        }
    }
    
    return cost_matrix;
}

/*-------------------------------------------------------------------*/
/*!
  \brief solve assignment problem using Kuhn-Munkres algorithm
*/
std::vector< int >
OMAM_Marking::solveAssignmentProblem( const std::vector< std::vector< double > > & cost_matrix )
{
    int n = cost_matrix.size();
    int m = cost_matrix[0].size();
    
    std::vector< int > assignment( n, -1 );
    std::vector< double > u( n, 0.0 );
    std::vector< double > v( m, 0.0 );
    std::vector< int > p( m, -1 );
    std::vector< int > way( m, -1 );
    
    for ( int i = 0; i < n; ++i )
    {
        p[0] = i;
        std::vector< double > minv( m, 1e9 );
        std::vector< bool > used( m, false );
        
        int j0 = 0;
        do
        {
            used[j0] = true;
            int i0 = p[j0];
            double delta = 1e9;
            int j1 = -1;
            
            for ( int j = 0; j < m; ++j )
            {
                if ( !used[j] )
                {
                    double cur = cost_matrix[i0][j] - u[i0] - v[j];
                    if ( cur < minv[j] )
                    {
                        minv[j] = cur;
                        way[j] = j0;
                    }
                    if ( minv[j] < delta )
                    {
                        delta = minv[j];
                        j1 = j;
                    }
                }
            }
            
            for ( int j = 0; j < m; ++j )
            {
                if ( used[j] )
                {
                    u[p[j]] += delta;
                    v[j] -= delta;
                }
                else
                {
                    minv[j] -= delta;
                }
            }
            
            j0 = j1;
        } while ( p[j0] != -1 );
        
        do
        {
            int j1 = way[j0];
            p[j0] = p[j1];
            j0 = j1;
        } while ( j0 != 0 );
    }
    
    for ( int j = 0; j < m; ++j )
    {
        if ( p[j] != -1 )
        {
            assignment[p[j]] = j;
        }
    }
    
    return assignment;
}

/*-------------------------------------------------------------------*/
/*!
  \brief calculate marking position for a defender against an opponent
*/
Vector2D
OMAM_Marking::calculateMarkingPosition( const WorldModel & world, const PlayerObject * defender, const PlayerObject * opponent )
{
    // Calculate the line from opponent to our goal
    Vector2D goal_pos( -ServerParam::i().pitchHalfLength(), 0.0 );
    Line2D opp_to_goal( opponent->pos(), goal_pos );
    
    // Find the point on this line that is between opponent and goal
    // and is at a distance of 1.5 meters from opponent (adjust as needed)
    Vector2D direction = ( goal_pos - opponent->pos() ).normalize();
    Vector2D marking_pos = opponent->pos() + direction * 1.5;
    
    // Ensure marking position is within field boundaries
    marking_pos.x = std::max( -ServerParam::i().pitchHalfLength(), std::min( ServerParam::i().pitchHalfLength(), marking_pos.x ) );
    marking_pos.y = std::max( -ServerParam::i().pitchHalfWidth(), std::min( ServerParam::i().pitchHalfWidth(), marking_pos.y ) );
    
    return marking_pos;
}
