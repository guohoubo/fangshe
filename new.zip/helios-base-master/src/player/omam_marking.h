// -*-c++-*-

/*!
  \file omam_marking.h
  \brief OMAM (Optimal Matching Assignment Marking) system implementation
*/

/*
 *Copyright:

 Copyright (C) Hidehisa AKIYAMA

 This code is free software; you can redistribute it and/or
 modify it under the terms of the GNU Lesser General Public
 License as published by the Free Software Foundation; either
 version 3 of the License, or (at your option) any later version.

 This library is distributed in the hope that it will be useful,
 but WITHOUT ANY WARRANTY; without even the implied warranty of
 MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 Lesser General Public License for more details.

 You should have received a copy of the GNU Lesser General Public
 License along with this library; if not, write to the Free Software
 Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

 *EndCopyright:
 */

/////////////////////////////////////////////////////////////////////

#ifndef RCSC_PLAYER_OMAM_MARKING_H
#define RCSC_PLAYER_OMAM_MARKING_H

#include <rcsc/geom/vector_2d.h>
#include <vector>

namespace rcsc {
class WorldModel;
class PlayerObject;
}

/*!
  \class OMAM_Marking
  \brief Optimal Matching Assignment Marking system
 */
class OMAM_Marking {
public:
    /*!
      \struct OpponentThreat
      \brief opponent threat information
     */
    struct OpponentThreat {
        const rcsc::PlayerObject * opp_; //!< pointer to opponent player
        double threat_score_; //!< threat score (higher is more dangerous)
        rcsc::Vector2D position_; //!< opponent position
        
        /*!
          \brief construct with opponent and threat score
          \param opp pointer to opponent player
          \param score threat score
         */
        OpponentThreat( const rcsc::PlayerObject * opp, double score )
            : opp_( opp )
            , threat_score_( score )
            , position_( opp->pos() )
          { }
    };
    
    /*!
      \struct MarkingAssignment
      \brief marking assignment information
     */
    struct MarkingAssignment {
        const rcsc::PlayerObject * defender_; //!< pointer to defender player
        const rcsc::PlayerObject * opponent_; //!< pointer to opponent player
        double cost_; //!< assignment cost
        rcsc::Vector2D marking_position_; //!< recommended marking position
        
        /*!
          \brief construct with defender, opponent, cost and marking position
          \param defender pointer to defender player
          \param opponent pointer to opponent player
          \param cost assignment cost
          \param pos recommended marking position
         */
        MarkingAssignment( const rcsc::PlayerObject * defender, const rcsc::PlayerObject * opponent, double cost, const rcsc::Vector2D & pos )
            : defender_( defender )
            , opponent_( opponent )
            , cost_( cost )
            , marking_position_( pos )
          { }
    };
    
private:
    //! maximum number of opponents to consider
    static const int MAX_OPPONENTS = 11;
    //! maximum number of defenders to consider
    static const int MAX_DEFENDERS = 11;
    
public:
    /*!
      \brief default constructor
     */
    OMAM_Marking() { }
    
    /*!
      \brief calculate opponent threats
      \param world const reference to the WorldModel
      \return vector of opponent threats sorted by threat score
     */
    std::vector< OpponentThreat > calculateOpponentThreats( const rcsc::WorldModel & world );
    
    /*!
      \brief assign marking tasks to defenders
      \param world const reference to the WorldModel
      \param threats vector of opponent threats
      \param k_top number of top threats to consider
      \return vector of marking assignments
     */
    std::vector< MarkingAssignment > assignMarkingTasks( const rcsc::WorldModel & world, const std::vector< OpponentThreat > & threats, int k_top );
    
    /*!
      \brief calculate marking position for a defender against an opponent
      \param world const reference to the WorldModel
      \param defender pointer to defender player
      \param opponent pointer to opponent player
      \return recommended marking position
     */
    rcsc::Vector2D calculateMarkingPosition( const rcsc::WorldModel & world, const rcsc::PlayerObject * defender, const rcsc::PlayerObject * opponent );
    
private:
    /*!
      \brief calculate threat score for an opponent
      \param world const reference to the WorldModel
      \param opp pointer to opponent player
      \return threat score
     */
    double calculateThreatScore( const rcsc::WorldModel & world, const rcsc::PlayerObject * opp );
    
    /*!
      \brief build cost matrix for assignment problem
      \param world const reference to the WorldModel
      \param defenders vector of defender players
      \param threats vector of opponent threats
      \return cost matrix
     */
    std::vector< std::vector< double > > buildCostMatrix( const rcsc::WorldModel & world, const std::vector< const rcsc::PlayerObject * > & defenders, const std::vector< OpponentThreat > & threats );
    
    /*!
      \brief solve assignment problem using Kuhn-Munkres algorithm
      \param cost_matrix cost matrix
      \return vector of assignments (defender index to opponent index)
     */
    std::vector< int > solveAssignmentProblem( const std::vector< std::vector< double > > & cost_matrix );
};

#endif // RCSC_PLAYER_OMAM_MARKING_H
